$(".container").slajd({
    time: "1000",
    auto: false,
});
